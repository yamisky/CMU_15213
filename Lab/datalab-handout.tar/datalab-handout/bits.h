//2
long implication(long, long);
long test_implication(long, long);
long leastBitPos(long);
long test_leastBitPos(long);
long distinctNegation(long);
long test_distinctNegation(long);
long fitsBits(long, long);
long test_fitsBits(long, long);
//3
long trueFiveEighths(long);
long test_trueFiveEighths(long);
long addOK(long, long);
long test_addOK(long, long);
long isPower2(long);
long test_isPower2(long);
long rotateLeft(long, long);
long test_rotateLeft(long, long);
//4
long isPalindrome(long);
long test_isPalindrome(long);
long bitParity(long);
long test_bitParity(long);
long absVal(long);
long test_absVal(long);
